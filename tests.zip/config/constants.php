<?php

return [
    'pagination_limit' => 10,
];
