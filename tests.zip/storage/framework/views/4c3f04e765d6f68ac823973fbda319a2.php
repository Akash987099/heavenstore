<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header pb-0 d-flex justify-content-between align-items-center">
                    <h6 class="m-0">Add</h6>
                </div>

                <div class="card-body px-4 pt-4 pb-2">
                    <form action="<?php echo e(route('product.update')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                        <div class="row g-3">
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="vehicle_name" class="form-label">Name</label>
                                    <input type="text" class="form-control" id="name" value="<?php echo e($product->name); ?>" name="name" placeholder="Enter Details" required>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="vehicle_number" class="form-label">Image</label>
                                    <input type="file" class="form-control" id="image" name="image" placeholder="Enter Details">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="vehicle_number" class="form-label fw-semibold mb-2">
                                        Old Image
                                    </label>

                                    <div class="border rounded-3 p-3 text-center bg-light position-relative">
                                        <img src="<?php echo e(asset($product->image)); ?>" alt="Old Image"
                                            class="img-fluid rounded-3 shadow-sm"
                                            style="max-height: 50px; object-fit: contain;">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="vehicle_name" class="form-label">Status</label>
                                    <select type="text" class="form-control" id="status" name="status" placeholder="Enter Details">
                                        <option value="active">Active</option>
                                        <option value="in_active">In Active</option>
                                    </select>    
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="vehicle_number" class="form-label">Price</label>
                                    <input type="text" class="form-control" id="price" value="<?php echo e($product->price); ?>" name="price" placeholder="Enter Details" required>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="vehicle_number" class="form-label">Actual Price</label>
                                    <input type="text" class="form-control" id="ac_price" name="ac_price" value="<?php echo e($product->ac_price); ?>" placeholder="Enter Details" required>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="vehicle_number" class="form-label">SKU Code</label>
                                    <input type="text" class="form-control" id="sku_code" name="sku_code" value="<?php echo e($product->sku_code); ?>" placeholder="Enter Details">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="vehicle_number" class="form-label">HSN Code</label>
                                    <input type="text" class="form-control" id="hsn_code" name="hsn_code" value="<?php echo e($product->hsn_code); ?>" placeholder="Enter Details">
                                </div>
                            </div>

                             <div class="col-md-6">
                                <div class="form-group">
                                    <label for="vehicle_name" class="form-label">Tags</label>
                                    <input type="text" class="form-control" id="tags" name="tags" value="<?php echo e($product->tags); ?>" placeholder="Enter Details">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="vehicle_number" class="form-label">Meta Tag</label>
                                    <input type="text" class="form-control" id="meta_tag" name="meta_tag" value="<?php echo e($product->meta_tag); ?>" placeholder="Enter Details">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="vehicle_name" class="form-label">Category</label>
                                    <select type="text" class="form-control" id="category" name="category" placeholder="Enter Details">
                                        <option value="">Select Category</option>
                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>    
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="vehicle_name" class="form-label">Sub Category</label>
                                    <select type="text" class="form-control" id="sub_category" name="sub_category" placeholder="Enter Details">
                                        <option value="">------Select sub Category------</option>
                                        <?php $__currentLoopData = $sub_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>" data-id="<?php echo e($item->category_id); ?>"><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>    
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="vehicle_name" class="form-label">Discount</label>
                                    <select type="text" class="form-control" id="discount" name="discount" placeholder="Enter Details">
                                        <option value="">------Select Discount------</option>
                                        <?php $__currentLoopData = $discount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>    
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="vehicle_name" class="form-label">Brands</label>
                                    <select type="text" class="form-control" id="brand" name="brand" placeholder="Enter Details" required>
                                        <option value="">------Select Brand------</option>
                                        <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>    
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="vehicle_number" class="form-label">Description</label>
                                    <textarea type="text" class="form-control" id="description" name="description" placeholder="Enter Details" required><?php echo $product->description; ?></textarea>
                                </div>
                            </div>

                        </div>

                        <div class="mt-4">
                            <button type="submit" class="btn btn-primary">Add</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    CKEDITOR.replace('description', {
        height: 300,
        removeButtons: 'PasteFromWord'
    });
</script>

<script>
            $(document).ready(function() {
                $('#status').val('<?php echo e($product->status); ?>');
                $('#category').val('<?php echo e($product->category); ?>');
                $('#sub_category').val('<?php echo e($product->sub_category); ?>');
                $('#store').val('<?php echo e($product->store); ?>');
                $('#discount').val('<?php echo e($product->discount); ?>');
                $('#summer').val('<?php echo e($product->summer_sale); ?>');
                $('#brand').val('<?php echo e($product->brands); ?>');
            });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\warehouse\resources\views/product/edit.blade.php ENDPATH**/ ?>