<!DOCTYPE html>
<html>
<head>
    <title>Email Verification</title>
</head>
<body>
    <h2>Email Verification OTP</h2>
    <p>Your OTP is:</p>
    <h1 style="letter-spacing:5px;"><?php echo e($otp); ?></h1>
    <p>This OTP is valid for verification only.</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\warehouse\resources\views/emails/otp.blade.php ENDPATH**/ ?>