<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\SubCategory;
use App\Models\Brand;

class CategoryController extends Controller
{
    protected $category;
    protected $subcategory;
    protected $brand;

    public function __construct()
    {
        $this->category = new Category();
        $this->subcategory = new SubCategory();
        $this->brand = new Brand();
    }

    public function category()
    {
        $category = $this->category->select('id', 'name', 'image')->get();

        if (!$category) {
            return response()->json([
                'status' => false,
                'message' => 'No record found!.'
            ], 403);
        }

        return response()->json([
            'status' => true,
            'data' => $category
        ], 200);
    }

    public function subCategory($id = null)
    {
        $subcategory = $this->subcategory
            ->select('id', 'category_id', 'name', 'image');

        if ($id) {
            $subcategory->where('category_id', $id);
        }

        $subcategory = $subcategory->get();

        if ($subcategory->isEmpty()) {
            return response()->json([
                'status' => false,
                'message' => 'No record found!'
            ], 404);
        }

        return response()->json([
            'status' => true,
            'data' => $subcategory
        ], 200);
    }

    public function brands()
    {
        $brands = $this->brand->select('id', 'name', 'image')->get();

        if (!$brands) {
            return response()->json([
                'status' => false,
                'message' => 'No record found!.'
            ], 403);
        }

        return response()->json([
            'status' => true,
            'data' => $brands
        ], 200);
    }
}
