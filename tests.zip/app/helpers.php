<?php

use App\Models\EmailTemplate;

if(!function_exists('email_temp')){
    function email_temp($name){
        return EmailTemplate::where('name', $name)->first();
    }
}